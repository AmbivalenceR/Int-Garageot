# INSTRUCTIONS
Découverte des tableaux et des formulaires

## HTML
- Utilisation des balises pour le tableau et pour les formulaires

## CSS
- Largeur du tableau : 90%
- Taille de la police :
    - par défaut : 1em
    - caption : 2em
    - thead : 1.6em

- Police utilisés :
    - titre, nav et thead : 'Lobster'
    - legend : 'Open Sans Condensed'
    - Texte : Verdana

##BONUS
Trouver comment alterner les couleurs de lignes sans class
